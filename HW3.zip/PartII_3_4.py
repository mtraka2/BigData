import os
import sys

os.environ['SPARK_HOME'] = '/usr/lib/spark'
os.environ['PYSPARK_PYTHON'] = '/usr/local/bin/python2.7'
os.environ['PYSPARK_SUBMIT_ARGS'] = ('--packages com.databricks:spark-csv_2.10:1.5.0 pyspark-shell')
os.environ['JAVA_TOOL_OPTIONS'] = "-Dhttps.protocols=TLSv1.2"

sys.path.append('/usr/lib/spark/python')
sys.path.append('/usr/lib/spark/python/lib/py4j-0.9-src.zip')


from pyspark import SparkContext
from pyspark import HiveContext


sc = SparkContext()
sqlContext = HiveContext(sc)

# template for importing csv file
df = sqlContext.read.format('com.databricks.spark.csv') \
    .options(header='true', inferschema='true') \
    .load('file:///home/cloudera/Downloads/tick_data.csv')

#df.show()

df.registerTempTable('tick')

query1 = sqlContext.sql('select count(distinct(DATE)) from tick')

query2 = sqlContext.sql('select count(distinct(SYM_ROOT)) from tick')

query3 = sqlContext.sql('select hour(TIME_M),sum(SIZE) from tick group by hour(TIME_M)')

sqlContext.sql('select  hour(TIME_M) HR_TIME,DATE DATE, SYM_ROOT ROOT, min(TIME_M) MIN_TIME from tick group by hour(TIME_M),SYM_ROOT,DATE').registerTempTable('Temp2')
sqlContext.sql('select tick.DATE,hour(tick.TIME_M) TIME_H,ROOT,tick.SIZE,tick.TRADE from temp2,tick where ROOT=SYM_ROOT and temp2.DATE=tick.DATE and tick.TIME_M = MIN_TIME').registerTempTable('Temp3')
sqlContext.sql('select  hour(TIME_M) HR_TIME,DATE DATE, SYM_ROOT ROOT, max(TIME_M) MAX_TIME from tick group by hour(TIME_M),SYM_ROOT,DATE').registerTempTable('Temp4')
sqlContext.sql('select tick.DATE,hour(tick.TIME_M) TIME_H,ROOT,tick.SIZE,tick.TRADE from temp4,tick where ROOT=SYM_ROOT and temp4.DATE=tick.DATE and tick.TIME_M = MAX_TIME').registerTempTable('Temp5')
query4 = sqlContext.sql('select temp3.DATE DATE, temp3.TIME_H TIME_H, temp3.ROOT SYM_ROOT, temp3.SIZE+temp5.SIZE SIZE, (temp5.TRADE-temp3.TRADE)/temp3.TRADE RETURN from temp3,temp5 where temp3.DATE=temp5.DATE and temp3.TIME_H=temp5.TIME_H and temp3.ROOT = temp5.ROOT order by temp3.DATE,temp3.TIME_H,temp3.ROOT')

# your code #
#############


# template for exporting you data in csv format
query4.coalesce(1).write.format('com.databricks.spark.csv') \
    .option('header', 'true') \
    .save('file:///home/cloudera/Downloads/output.csv')

# stop spark session at the end
sc.stop()